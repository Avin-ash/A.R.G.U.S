
"use strict";

let GetPolledImage = require('./GetPolledImage.js')

module.exports = {
  GetPolledImage: GetPolledImage,
};
