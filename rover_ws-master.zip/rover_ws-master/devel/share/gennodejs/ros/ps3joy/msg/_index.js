
"use strict";

let try2 = require('./try2.js');

module.exports = {
  try2: try2,
};
