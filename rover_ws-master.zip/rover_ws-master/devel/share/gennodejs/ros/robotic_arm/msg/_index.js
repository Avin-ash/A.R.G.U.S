
"use strict";

let ghusa = require('./ghusa.js');

module.exports = {
  ghusa: ghusa,
};
